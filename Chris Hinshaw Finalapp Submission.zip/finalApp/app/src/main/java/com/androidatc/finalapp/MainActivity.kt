package com.androidatc.finalapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        metricBtn.setOnClickListener {
            val intent = Intent(this, Metric::class.java)
            startActivity(intent)
        }

        englishBtn.setOnClickListener {
            val intent = Intent(this, English::class.java)
            startActivity(intent)

        }

    }

    fun display(view: View) {
        info.text="The purpose of this app is to perform a conversion of mass, temperature, or length from " +
                "metric units to english units or vice versa. " +
                "To navigate first select if you want to convert metric units into english units (metric " +
                "button)or convert english units into metric units (english button). " +
                "Then select the type of unit you would like to convert. Finally enter your" +
                "values, select your units and calculate"
    }
}