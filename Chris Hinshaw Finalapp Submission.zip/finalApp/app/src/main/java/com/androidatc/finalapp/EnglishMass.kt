package com.androidatc.finalapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_english_mass.*
import kotlinx.android.synthetic.main.activity_metric_mass.*

class EnglishMass : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_english_mass)
        val actionBar = supportActionBar

        actionBar!!.title = "EnglishMass"
    }
    fun onCalBtn4(view: View){
        var weight =0.0
        var n1=editTextNumber4.text
        when {
            radioButton.isChecked -> weight= 28.35
            radioButton2.isChecked -> weight = 28350.00

        }
        val sumResult=n1.toString().toDouble()* weight

        textView12.text=sumResult.toString()
    }
}