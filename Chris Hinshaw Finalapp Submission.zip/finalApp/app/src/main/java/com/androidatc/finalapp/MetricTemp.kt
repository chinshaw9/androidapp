package com.androidatc.finalapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import kotlinx.android.synthetic.main.activity_metric_temp.*

class MetricTemp : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_metric_temp)


        val actionBar = supportActionBar

        actionBar!!.title = "MetricTemp"


        val n1=editTextNumber2.text

        calBtn2.setOnClickListener {
            val sumResult= n1.toString().toDouble()* 9/5 +32
            textView15.text= sumResult.toString()
        }
    }

    }
