package com.androidatc.finalapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_english.*
import kotlinx.android.synthetic.main.activity_metric.*

class English : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_english)

        val actionBar = supportActionBar

        actionBar!!.title = "English"
        actionBar.setDisplayHomeAsUpEnabled(true)

        mass1.setOnClickListener {
            val intent = Intent(this, EnglishMass::class.java)
            startActivity(intent)
        }

        temp1.setOnClickListener {
            val intent = Intent(this, EnglishTemp::class.java)
            startActivity(intent)
        }
        length1.setOnClickListener {
            val intent = Intent(this, EnglishLength::class.java)
            startActivity(intent)

        }
    }
}