package com.androidatc.finalapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_metric.*

class Metric : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_metric)

        val actionBar = supportActionBar

        actionBar!!.title = "Metric"
        actionBar.setDisplayHomeAsUpEnabled(true)

        mass.setOnClickListener {
            val intent = Intent(this, MetricMass::class.java)
            startActivity(intent)
        }

        temp.setOnClickListener {
            val intent = Intent(this, MetricTemp::class.java)
            startActivity(intent)
        }
        length.setOnClickListener {
            val intent = Intent(this, MetricLength::class.java)
            startActivity(intent)
        }
    }

}