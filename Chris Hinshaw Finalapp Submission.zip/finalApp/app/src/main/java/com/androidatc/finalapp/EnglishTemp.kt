package com.androidatc.finalapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_english_temp.*
import kotlinx.android.synthetic.main.activity_metric_temp.*

class EnglishTemp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_english_temp)

        val actionBar = supportActionBar

        actionBar!!.title = "EnglishTemp"


        val n1 = editTextNumber5.text

        calBtn5.setOnClickListener {
            val sumResult = (n1.toString().toDouble() - 32) * 5 / 9
            textView18.text = sumResult.toString()
        }
    }
}