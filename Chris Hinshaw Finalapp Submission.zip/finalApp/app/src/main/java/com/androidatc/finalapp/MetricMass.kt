package com.androidatc.finalapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_metric_mass.*

class MetricMass : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_metric_mass)

        val actionBar = supportActionBar

        actionBar!!.title = "MetricMass"

    }
    fun onCalBtn1(view: View){
        var weight =0.0
        var n1=editTextNumber.text
        when {
            radioButton6.isChecked -> weight= 28.35
            radioButton7.isChecked -> weight = 453.6

        }
        val sumResult=n1.toString().toDouble()/ weight

            textView9.text=sumResult.toString()
        }

        }

