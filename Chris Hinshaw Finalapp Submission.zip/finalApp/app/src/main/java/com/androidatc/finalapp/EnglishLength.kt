package com.androidatc.finalapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_english_length.*
import kotlinx.android.synthetic.main.activity_metric_length.*

class EnglishLength : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_english_length)

        val actionBar = supportActionBar

        actionBar!!.title = "EnglishLength"

    }

    fun onCalBtn6(view: View) {
        var length = 0.0
        var n1 = editTextNumber6.text
        when {
            radioButton15.isChecked -> length = 2.54
            radioButton16.isChecked -> length = 25.4

        }
        val sumResult = n1.toString().toDouble() * length

        textView22.text = sumResult.toString()
    }
}