package com.androidatc.finalapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_metric_length.*

class MetricLength : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_metric_length)

        val actionBar = supportActionBar

        actionBar!!.title = "MetricLength"
    }

        fun onCalBtn13(view: View) {
            var length = 0.0
            var n1 = editTextNumber3.text
            when {
                radioButton10.isChecked -> length = 2.54
                radioButton12.isChecked -> length = 30.48

            }
            val sumResult = n1.toString().toDouble() / length

            textView13.text = sumResult.toString()

        }
        }
